#include <jni.h>
#include <string>


extern "C"
JNIEXPORT jint JNICALL
Java_com_motorola_developer_jnitests_NLib_add(JNIEnv *env, jclass type, jint a, jint b) {

    return a+b;

}

extern "C"
JNIEXPORT jint JNICALL
Java_com_motorola_developer_jnitests_NLib_sub(JNIEnv *env, jobject obj, jint a, jint b) {


    // obj->getNum(a+b);
    jclass cl=env->GetObjectClass(obj);

    jmethodID m=env->GetMethodID(cl,"getNum","(I)I");

    jint num=env->CallIntMethod(obj,m,a+b);

    return num;

}