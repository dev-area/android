#include <jni.h>
#include <string>

static jint myadd(JNIEnv *env, jclass clazz, jint a,jint b) {
    return a+b;
}

static jint mysub(JNIEnv *env, jclass clazz, jint a,jint b) {
    return a+b;
}

static JNINativeMethod method_table[] = {
        { "add20", "(II)I", (void *) myadd },
        { "sub", "(II)I", (void *) mysub },
};




jint JNI_OnLoad(JavaVM* vm, void* reserved) {

    JNIEnv* env;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    } else {
        jclass clazz = env->FindClass("com/developer/myapplication/MainActivity");
        if (clazz) {
            jint ret = env->RegisterNatives(clazz, method_table, sizeof(method_table) / sizeof(method_table[0]));
            env->DeleteLocalRef(clazz);
            return ret == 0 ? JNI_VERSION_1_6 : JNI_ERR;
        } else {
            return JNI_ERR;
        }
    }
}